<h1>CamAR | CamAR</h1>
<h2>Visualization By Just One Click</h2>
<hr>
<div>
	<h3>Technologies</h3>
  	<ul>
		<li>HTML & CSS</li>
		<li>Bootstrap</li>
		<li>JavaScript & Jquery</li>
		<li>Ajax</li>
		<li>PHP & MYSQL</li>
	</ul>
</div>
<hr>
<div>
	<h3></h3>
  	<ul>
		<li>Admin Login Page: http://localhost/CamAR/admin/</li>
	</ul>
	<p>
		Username: admin
		<br>
		Password: 123456789
	</p>
</div>
<hr>
<div>
	<h3>Installation</h3>
  	<ol>
		<li>Download the files + database file (.sql)</li>
		<li>Create new database with the name "restaurant_website" and then Import the sql file downloaded </li>
		<li>Check the files connect.php to make sure that everything is working</li>
		<li>The website is ready to use</li>
		<li>Feel free to edit the missig parts or the existing parts</li>
	</ol>
</div>
